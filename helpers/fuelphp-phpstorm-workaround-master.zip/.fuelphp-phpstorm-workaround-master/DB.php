<?php
class DB extends Fuel\Core\Db
{
}