<?php
class Cache_Handler_Serialized extends Fuel\Core\Cache_Handler_Serialized
{
}