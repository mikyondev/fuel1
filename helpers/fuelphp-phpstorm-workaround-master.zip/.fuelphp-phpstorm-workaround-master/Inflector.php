<?php
class Inflector extends Fuel\Core\Inflector
{
}