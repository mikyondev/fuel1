<?php
class Database_Mysql_Result extends Fuel\Core\Database_Mysql_Result
{
}