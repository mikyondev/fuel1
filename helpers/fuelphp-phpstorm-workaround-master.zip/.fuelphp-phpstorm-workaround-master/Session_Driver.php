<?php
class Session_Driver extends Fuel\Core\Session_Driver
{
}