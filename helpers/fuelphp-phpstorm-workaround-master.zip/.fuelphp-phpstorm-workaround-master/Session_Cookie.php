<?php
class Session_Cookie extends Fuel\Core\Session_Cookie
{
}