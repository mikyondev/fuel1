<?php
class Request extends Fuel\Core\Request
{
}