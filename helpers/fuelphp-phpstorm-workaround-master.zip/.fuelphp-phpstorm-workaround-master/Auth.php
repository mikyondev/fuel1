<?php
class Auth extends \Auth\Auth
{
}