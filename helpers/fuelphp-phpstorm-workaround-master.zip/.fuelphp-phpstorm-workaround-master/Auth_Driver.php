<?php
class Auth_Driver extends \Auth\Auth_Driver
{
}