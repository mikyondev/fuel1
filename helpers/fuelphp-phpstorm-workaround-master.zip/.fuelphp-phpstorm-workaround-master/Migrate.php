<?php
class Migrate extends Fuel\Core\Migrate
{
}