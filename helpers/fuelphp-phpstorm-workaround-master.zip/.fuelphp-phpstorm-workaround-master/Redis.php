<?php
class Redis extends Fuel\Core\Redis
{
}