<?php
class Fieldset extends Fuel\Core\Fieldset
{
}