<?php
class Database_Connection extends Fuel\Core\Database_Connection
{
}