<?php
class Session_Memcached extends Fuel\Core\Session_Memcached
{
}