<?php
class Auth_Login_Driver extends \Auth\Auth_Login_Driver
{
}