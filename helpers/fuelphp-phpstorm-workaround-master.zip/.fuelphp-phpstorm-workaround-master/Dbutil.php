<?php
class Dbutil extends Fuel\Core\Dbutil
{
}