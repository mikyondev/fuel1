<?php
class Router extends Fuel\Core\Router
{
}