<?php
class Database_Exception extends Fuel\Core\Database_Exception
{
}