<?php
class Fuel_Exception extends Fuel\Core\Fuel_Exception
{
}