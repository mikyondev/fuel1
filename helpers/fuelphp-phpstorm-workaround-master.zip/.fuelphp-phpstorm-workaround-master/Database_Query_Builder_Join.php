<?php
class Database_Query_Builder_Join extends Fuel\Core\Database_Query_Builder_Join
{
}