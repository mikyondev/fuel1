<?php
class Asset extends Fuel\Core\Asset
{
}