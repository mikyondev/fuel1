<?php
class Config extends Fuel\Core\Config
{
}