<?php
class Route extends Fuel\Core\Route
{
}