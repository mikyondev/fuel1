<?php
class Error extends Fuel\Core\Error
{
}