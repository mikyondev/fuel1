<?php
class Pagination extends Fuel\Core\Pagination
{
}