<?php
class Model extends Fuel\Core\Model
{
}