<?php
class Security extends Fuel\Core\Security
{
}