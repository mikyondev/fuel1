<?php
class FuelException extends \Fuel\Core\FuelException
{
}