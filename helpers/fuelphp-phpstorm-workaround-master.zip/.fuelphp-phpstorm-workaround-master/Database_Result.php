<?php
class Database_Result extends Fuel\Core\Database_Result
{
}