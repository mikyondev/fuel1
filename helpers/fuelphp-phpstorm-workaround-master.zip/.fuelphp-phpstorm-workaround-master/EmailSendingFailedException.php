<?php
class EmailSendingFailedException extends \Email\EmailSendingFailedException {}