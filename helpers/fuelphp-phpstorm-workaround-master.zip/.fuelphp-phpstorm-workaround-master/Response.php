<?php
class Response extends Fuel\Core\Response
{
}