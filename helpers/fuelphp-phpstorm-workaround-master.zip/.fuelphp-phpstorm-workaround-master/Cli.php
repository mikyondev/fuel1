<?php
class Cli extends Fuel\Core\Cli
{
}