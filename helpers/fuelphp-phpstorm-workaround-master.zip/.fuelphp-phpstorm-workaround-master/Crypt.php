<?php
class Crypt extends Fuel\Core\Crypt
{
}