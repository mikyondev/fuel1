<?php
class Database_Result_Cached extends Fuel\Core\Database_Result_Cached
{
}