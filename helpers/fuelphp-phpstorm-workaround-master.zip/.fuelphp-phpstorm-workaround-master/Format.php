<?php
class Format extends Fuel\Core\Format
{
}