<?php
class Unzip extends Fuel\Core\Unzip
{
}