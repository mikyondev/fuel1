<?php
class Database_Transaction extends Fuel\Core\Database_Transaction
{
}