<?php
class Email_Driver extends \Email\Email_Driver
{
}