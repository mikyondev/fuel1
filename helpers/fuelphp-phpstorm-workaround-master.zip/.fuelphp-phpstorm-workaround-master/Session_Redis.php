<?php
class Session_Redis extends Fuel\Core\Session_Redis
{
}