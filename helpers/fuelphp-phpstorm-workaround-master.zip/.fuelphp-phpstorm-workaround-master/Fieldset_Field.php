<?php
class Fieldset_Field extends Fuel\Core\Fieldset_Field
{
}