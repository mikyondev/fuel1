<?php
class Controller_Rest extends Fuel\Core\Controller_Rest
{
}