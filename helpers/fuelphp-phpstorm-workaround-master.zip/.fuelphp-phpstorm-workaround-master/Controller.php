<?php
class Controller extends Fuel\Core\Controller
{
}