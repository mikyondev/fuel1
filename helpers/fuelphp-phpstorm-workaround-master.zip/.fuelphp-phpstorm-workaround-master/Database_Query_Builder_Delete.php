<?php
class Database_Query_Builder_Delete extends Fuel\Core\Database_Query_Builder_Delete
{
}