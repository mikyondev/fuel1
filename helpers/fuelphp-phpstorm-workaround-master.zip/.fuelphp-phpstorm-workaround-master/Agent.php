<?php
class Agent extends Fuel\Core\Agent
{
}