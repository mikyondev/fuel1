<?php
class Session_File extends Fuel\Core\Session_File
{
}