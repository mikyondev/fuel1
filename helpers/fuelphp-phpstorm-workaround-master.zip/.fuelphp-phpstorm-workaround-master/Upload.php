<?php
class Upload extends Fuel\Core\Upload
{
}