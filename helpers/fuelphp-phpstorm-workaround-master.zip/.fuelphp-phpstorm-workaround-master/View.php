<?php
class View extends Fuel\Core\View
{
}