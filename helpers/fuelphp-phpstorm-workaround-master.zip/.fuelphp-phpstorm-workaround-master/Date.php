<?php
class Date extends Fuel\Core\Date
{
}