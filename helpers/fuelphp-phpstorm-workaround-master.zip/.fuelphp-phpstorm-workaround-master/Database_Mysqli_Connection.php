<?php
class Database_Mysqli_Connection extends Fuel\Core\Database_Mysqli_Connection
{
}