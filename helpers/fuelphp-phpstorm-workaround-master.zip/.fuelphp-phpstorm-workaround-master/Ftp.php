<?php
class Ftp extends Fuel\Core\Ftp
{
}