<?php
class Database_Query extends Fuel\Core\Database_Query
{
}