<?php
class Session_Db extends Fuel\Core\Session_Db
{
}