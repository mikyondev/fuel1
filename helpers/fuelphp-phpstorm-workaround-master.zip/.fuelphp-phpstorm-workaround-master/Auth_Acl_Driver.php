<?php
class Auth_Acl_Driver extends \Auth\Auth_Acl_Driver
{
}