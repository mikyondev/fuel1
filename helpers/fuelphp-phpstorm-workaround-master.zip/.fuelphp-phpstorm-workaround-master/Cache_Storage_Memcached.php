<?php
class Cache_Storage_Memcached extends Fuel\Core\Cache_Storage_Memcached
{
}