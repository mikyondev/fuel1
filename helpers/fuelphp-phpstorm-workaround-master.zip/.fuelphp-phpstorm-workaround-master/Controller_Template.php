<?php
class Controller_Template extends Fuel\Core\Controller_Template
{
}