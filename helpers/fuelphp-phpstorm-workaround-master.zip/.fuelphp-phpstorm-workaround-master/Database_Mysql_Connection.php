<?php
class Database_Mysql_Connection extends Fuel\Core\Database_Mysql_Connection
{
}