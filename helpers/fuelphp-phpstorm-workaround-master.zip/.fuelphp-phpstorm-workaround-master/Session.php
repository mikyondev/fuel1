<?php
class Session extends Fuel\Core\Session
{

}