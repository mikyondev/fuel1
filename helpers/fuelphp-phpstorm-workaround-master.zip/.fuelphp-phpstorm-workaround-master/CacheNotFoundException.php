<?php
class CacheNotFoundException extends Fuel\Core\CacheNotFoundException
{
}