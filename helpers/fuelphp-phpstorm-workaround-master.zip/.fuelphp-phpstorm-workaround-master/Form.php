<?php
class Form extends Fuel\Core\Form
{
}