<?php
class Debug extends Fuel\Core\Debug
{
}