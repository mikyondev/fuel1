<?php
class Cache_Storage_Redis extends Fuel\Core\Cache_Storage_Redis
{
}