<?php
class Fuel extends Fuel\Core\Fuel
{
}