<?php
class Session_Exception extends Fuel\Core\Session_Exception
{
}