<?php
class CacheExpiredException extends Fuel\Core\CacheExpiredException
{
}