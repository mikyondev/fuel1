<?php
class Email extends \Email\Email
{
}