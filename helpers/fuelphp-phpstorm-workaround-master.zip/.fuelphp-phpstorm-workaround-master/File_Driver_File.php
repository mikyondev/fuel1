<?php
class File_Driver_File extends Fuel\Core\File_Handler_File
{
}