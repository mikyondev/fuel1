<?php
class Email_Driver_Smtp extends \Email\Email_Driver_Smtp
{
}