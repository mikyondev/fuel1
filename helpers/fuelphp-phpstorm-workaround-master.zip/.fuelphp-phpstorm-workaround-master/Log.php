<?php
class Log extends Fuel\Core\Log
{
}