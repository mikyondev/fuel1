<?php
class Html extends Fuel\Core\Html
{
}