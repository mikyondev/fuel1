<?php
class Cookie extends Fuel\Core\Cookie
{
}