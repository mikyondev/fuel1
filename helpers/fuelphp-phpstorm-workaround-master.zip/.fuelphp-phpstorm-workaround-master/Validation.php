<?php
class Validation extends Fuel\Core\Validation
{
}