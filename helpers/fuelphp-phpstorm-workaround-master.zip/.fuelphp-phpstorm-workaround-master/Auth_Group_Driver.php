<?php
class Auth_Group_Driver extends \Auth\Auth_Group_Driver
{
}