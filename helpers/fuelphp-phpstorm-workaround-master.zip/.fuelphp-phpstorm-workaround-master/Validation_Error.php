<?php
class Validation_Error extends Fuel\Core\Validation_Error
{
}