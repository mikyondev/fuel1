<?php
class Testcase extends Fuel\Core\Testcase
{
}