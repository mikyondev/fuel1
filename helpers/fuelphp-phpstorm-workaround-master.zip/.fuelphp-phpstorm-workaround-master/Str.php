<?php
class Str extends Fuel\Core\Str
{
}