<?php
class Image_Gd extends Fuel\Core\Image_Gd
{
}