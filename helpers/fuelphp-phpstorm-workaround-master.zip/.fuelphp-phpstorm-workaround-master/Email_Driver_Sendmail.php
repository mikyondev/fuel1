<?php
class Email_Driver_Sendmail extends \Email\Email_Driver_Sendmail
{
}