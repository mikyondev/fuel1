<?php
class Cache_Storage_File extends Fuel\Core\Cache_Storage_File
{
}