<?php
class Image extends Fuel\Core\Image
{
}