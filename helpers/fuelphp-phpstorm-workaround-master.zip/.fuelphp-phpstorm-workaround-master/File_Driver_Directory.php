<?php
class File_Driver_Directory extends Fuel\Core\File_Handler_Directory
{
}