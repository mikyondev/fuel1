<?php
class Image_Imagemagick extends Fuel\Core\Image_Imagemagick
{
}