<?php
class Cache_Handler_Json extends Fuel\Core\Cache_Handler_Json
{
}