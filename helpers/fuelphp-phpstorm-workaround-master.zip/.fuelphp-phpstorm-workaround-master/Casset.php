<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Anton
 * Date: 31/01/12
 * Time: 09:24
 * To change this template use File | Settings | File Templates.
 */
class Casset extends \Casset\Casset
{

}
