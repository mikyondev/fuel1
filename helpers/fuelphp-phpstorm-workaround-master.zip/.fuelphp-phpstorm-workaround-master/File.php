<?php
class File extends Fuel\Core\File
{
}