<?php
class Database_Pdo_Connection extends Fuel\Core\Database_Pdo_Connection
{
}