<?php
class File_Area extends Fuel\Core\File_Area
{
}