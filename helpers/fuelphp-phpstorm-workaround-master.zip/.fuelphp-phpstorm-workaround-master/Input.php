<?php
class Input extends Fuel\Core\Input
{
}