<?php
class Arr extends Fuel\Core\Arr
{
}