<?php
class Viewmodel extends Fuel\Core\Viewmodel
{
}