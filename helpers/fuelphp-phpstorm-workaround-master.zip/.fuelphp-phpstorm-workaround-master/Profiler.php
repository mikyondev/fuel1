<?php
class Profiler extends Fuel\Core\Profiler
{
}