<?php
class Uri extends Fuel\Core\Uri
{
}