<?php
class Package extends \Fuel\Core\Package {}