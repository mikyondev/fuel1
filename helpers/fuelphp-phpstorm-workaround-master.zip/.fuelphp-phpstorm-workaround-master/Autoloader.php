<?php
class Autoloader extends \Fuel\Core\Autoloader {


}