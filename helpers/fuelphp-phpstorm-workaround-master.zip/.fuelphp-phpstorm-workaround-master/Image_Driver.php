<?php
class Image_Driver extends Fuel\Core\Image_Driver
{
}