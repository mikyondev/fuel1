<?php
class Lang extends Fuel\Core\Lang
{
}