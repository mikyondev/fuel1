<?php
class Mongo_Db extends Fuel\Core\Mongo_Db
{
}