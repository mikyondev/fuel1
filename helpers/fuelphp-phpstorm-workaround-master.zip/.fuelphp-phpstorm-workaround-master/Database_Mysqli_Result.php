<?php
class Database_Mysqli_Result extends Fuel\Core\Database_Mysqli_Result
{
}