<?php
class Database_Expression extends Fuel\Core\Database_Expression
{
}