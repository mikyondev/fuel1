<?php
class Cache_Storage_Driver extends Fuel\Core\Cache_Storage_Driver
{
}