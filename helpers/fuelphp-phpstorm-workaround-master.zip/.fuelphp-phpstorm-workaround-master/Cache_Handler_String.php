<?php
class Cache_Handler_String extends Fuel\Core\Cache_Handler_String
{
}