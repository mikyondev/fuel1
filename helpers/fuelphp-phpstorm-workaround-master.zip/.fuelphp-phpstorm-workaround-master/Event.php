<?php
class Event extends Fuel\Core\Event
{
}