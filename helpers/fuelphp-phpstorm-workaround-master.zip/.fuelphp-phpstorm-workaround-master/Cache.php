<?php
class Cache extends Fuel\Core\Cache
{
}